﻿using System;
using System.Collections.ObjectModel;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WaiteringSystem.Business;

namespace WaiteringSystem.Presentation
{
    public partial class EmployeeListingForm : Form
    {
        public bool listFormClosed = false;

        private Collection<Employee> employees;
        private Role.RoleType roleValue;
        private EmployeeController employeeController;

        public Role.RoleType RoleValue
        {
            set
            {
                roleValue = value;
            }
        }

        public EmployeeListingForm(EmployeeController empController)
        {
            InitializeComponent();

            employeeController = empController;

            this.FormClosed += EmployeeListingForm_FormClosed;
            this.Load += EmployeeListingForm_Load;
            this.Activated += EmployeeListingForm_Activated;
        }
        public void setUpEmployeeListView()
        {
            ListViewItem employeeDetails;
            HeadWaiter headW;
            Waiter waiter;
            Runner runner;

            employees = null;

            employeeListView.Clear();

            employeeListView.Columns.Insert(0, "ID", 80, HorizontalAlignment.Left);
            employeeListView.Columns.Insert(1, "EMPID", 100, HorizontalAlignment.Left);
            employeeListView.Columns.Insert(2, "Name", 150, HorizontalAlignment.Left);
            employeeListView.Columns.Insert(3, "Phone", 120, HorizontalAlignment.Left);
            employeeListView.Columns.Insert(4, "Payment", 100, HorizontalAlignment.Center);
            employeeListView.Columns.Insert(5, "Role", 120, HorizontalAlignment.Center);

            switch (roleValue)
            {
                case Role.RoleType.NoRole:

                    employees = employeeController.AllEmployees;
                    listLabel.Text = "Listing of all employees";

                    break;

                case Role.RoleType.Headwaiter:

                    employees = employeeController.FindByRole(
                        employeeController.AllEmployees,
                        Role.RoleType.Headwaiter);

                    listLabel.Text = "Listing of all Headwaiters";

                    break;

                case Role.RoleType.Waiter:

                    employees = employeeController.FindByRole(
                        employeeController.AllEmployees,
                        Role.RoleType.Waiter);

                    listLabel.Text = "Listing of all Waiters";

                    break;

                case Role.RoleType.Runner:

                    employees = employeeController.FindByRole(
                        employeeController.AllEmployees,
                        Role.RoleType.Runner);

                    listLabel.Text = "Listing of all Runners";

                    break;
            }

            foreach (Employee employee in employees)
            {
                employeeDetails = new ListViewItem();

                employeeDetails.Text = employee.ID.ToString();
                employeeDetails.SubItems.Add(employee.EmployeeID);
                employeeDetails.SubItems.Add(employee.Name);
                employeeDetails.SubItems.Add(employee.Telephone);

                switch (employee.role.getRoleValue)
                {
                    case Role.RoleType.Headwaiter:

                        headW = (HeadWaiter)employee.role;

                        employeeDetails.SubItems.Add(
                            headW.SalaryAmount.ToString());

                        employeeDetails.SubItems.Add("Headwaiter");

                        break;

                    case Role.RoleType.Waiter:

                        waiter = (Waiter)employee.role;

                        employeeDetails.SubItems.Add(
                            waiter.getTips.ToString());

                        employeeDetails.SubItems.Add("Waiter");

                        break;

                    case Role.RoleType.Runner:

                        runner = (Runner)employee.role;

                        employeeDetails.SubItems.Add(
                            runner.getTips.ToString());

                        employeeDetails.SubItems.Add("Runner");

                        break;
                }

                employeeListView.Items.Add(employeeDetails);
            }

            employeeListView.Refresh();
            employeeListView.GridLines = true;
        }

        private void EmployeeListingForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            listFormClosed = true;
        }

        private void EmployeeListingForm_Load(object sender, EventArgs e)
        {
            employeeListView.View = View.Details;
        }

        private void EmployeeListingForm_Activated(object sender, EventArgs e)
        {
            employeeListView.View = View.Details;
        }
    }
}

