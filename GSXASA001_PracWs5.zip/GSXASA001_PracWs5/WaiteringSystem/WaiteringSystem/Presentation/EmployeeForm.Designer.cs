﻿namespace WaiteringSystem.Presentation
{
    partial class EmployeeForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnCancel = new System.Windows.Forms.Button();
            this.idLabel = new System.Windows.Forms.Label();
            this.idTextBox = new System.Windows.Forms.TextBox();
            this.tipsLabel = new System.Windows.Forms.Label();
            this.empIDLabel = new System.Windows.Forms.Label();
            this.hoursLabel = new System.Windows.Forms.Label();
            this.paymentLabel = new System.Windows.Forms.Label();
            this.phoneLabel = new System.Windows.Forms.Label();
            this.nameLabel = new System.Windows.Forms.Label();
            this.empIDTextBox = new System.Windows.Forms.TextBox();
            this.tipsTextBox = new System.Windows.Forms.TextBox();
            this.hoursTextBox = new System.Windows.Forms.TextBox();
            this.paymentTextBox = new System.Windows.Forms.TextBox();
            this.phoneTextBox = new System.Windows.Forms.TextBox();
            this.nameTextBox = new System.Windows.Forms.TextBox();
            this.btnExit = new System.Windows.Forms.Button();
            this.btnSubmit = new System.Windows.Forms.Button();
            this.headWaitronRadioButton = new System.Windows.Forms.RadioButton();
            this.runnerRadioButton = new System.Windows.Forms.RadioButton();
            this.waitronRadioButton = new System.Windows.Forms.RadioButton();
            this.SuspendLayout();
            // 
            // btnCancel
            // 
            this.btnCancel.Location = new System.Drawing.Point(363, 388);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(75, 23);
            this.btnCancel.TabIndex = 0;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.cancelButton_Click);
            // 
            // idLabel
            // 
            this.idLabel.AutoSize = true;
            this.idLabel.Location = new System.Drawing.Point(44, 102);
            this.idLabel.Name = "idLabel";
            this.idLabel.Size = new System.Drawing.Size(18, 13);
            this.idLabel.TabIndex = 1;
            this.idLabel.Text = "ID";
            // 
            // idTextBox
            // 
            this.idTextBox.Location = new System.Drawing.Point(139, 95);
            this.idTextBox.Name = "idTextBox";
            this.idTextBox.Size = new System.Drawing.Size(100, 20);
            this.idTextBox.TabIndex = 2;
            // 
            // tipsLabel
            // 
            this.tipsLabel.AutoSize = true;
            this.tipsLabel.Location = new System.Drawing.Point(44, 338);
            this.tipsLabel.Name = "tipsLabel";
            this.tipsLabel.Size = new System.Drawing.Size(27, 13);
            this.tipsLabel.TabIndex = 3;
            this.tipsLabel.Text = "Tips";
            // 
            // empIDLabel
            // 
            this.empIDLabel.AutoSize = true;
            this.empIDLabel.Location = new System.Drawing.Point(392, 95);
            this.empIDLabel.Name = "empIDLabel";
            this.empIDLabel.Size = new System.Drawing.Size(67, 13);
            this.empIDLabel.TabIndex = 4;
            this.empIDLabel.Text = "Employee ID";
            // 
            // hoursLabel
            // 
            this.hoursLabel.AutoSize = true;
            this.hoursLabel.Location = new System.Drawing.Point(44, 295);
            this.hoursLabel.Name = "hoursLabel";
            this.hoursLabel.Size = new System.Drawing.Size(35, 13);
            this.hoursLabel.TabIndex = 5;
            this.hoursLabel.Text = "Hours";
            // 
            // paymentLabel
            // 
            this.paymentLabel.AutoSize = true;
            this.paymentLabel.Location = new System.Drawing.Point(44, 242);
            this.paymentLabel.Name = "paymentLabel";
            this.paymentLabel.Size = new System.Drawing.Size(48, 13);
            this.paymentLabel.TabIndex = 6;
            this.paymentLabel.Text = "Payment";
            // 
            // phoneLabel
            // 
            this.phoneLabel.AutoSize = true;
            this.phoneLabel.Location = new System.Drawing.Point(44, 193);
            this.phoneLabel.Name = "phoneLabel";
            this.phoneLabel.Size = new System.Drawing.Size(38, 13);
            this.phoneLabel.TabIndex = 7;
            this.phoneLabel.Text = "Phone";
            // 
            // nameLabel
            // 
            this.nameLabel.AutoSize = true;
            this.nameLabel.Location = new System.Drawing.Point(44, 152);
            this.nameLabel.Name = "nameLabel";
            this.nameLabel.Size = new System.Drawing.Size(35, 13);
            this.nameLabel.TabIndex = 8;
            this.nameLabel.Text = "Name";
            // 
            // empIDTextBox
            // 
            this.empIDTextBox.Location = new System.Drawing.Point(510, 88);
            this.empIDTextBox.Name = "empIDTextBox";
            this.empIDTextBox.Size = new System.Drawing.Size(100, 20);
            this.empIDTextBox.TabIndex = 9;
            // 
            // tipsTextBox
            // 
            this.tipsTextBox.Location = new System.Drawing.Point(139, 335);
            this.tipsTextBox.Name = "tipsTextBox";
            this.tipsTextBox.Size = new System.Drawing.Size(100, 20);
            this.tipsTextBox.TabIndex = 10;
            // 
            // hoursTextBox
            // 
            this.hoursTextBox.Location = new System.Drawing.Point(139, 288);
            this.hoursTextBox.Name = "hoursTextBox";
            this.hoursTextBox.Size = new System.Drawing.Size(100, 20);
            this.hoursTextBox.TabIndex = 11;
            // 
            // paymentTextBox
            // 
            this.paymentTextBox.Location = new System.Drawing.Point(139, 235);
            this.paymentTextBox.Name = "paymentTextBox";
            this.paymentTextBox.Size = new System.Drawing.Size(100, 20);
            this.paymentTextBox.TabIndex = 12;
            // 
            // phoneTextBox
            // 
            this.phoneTextBox.Location = new System.Drawing.Point(139, 186);
            this.phoneTextBox.Name = "phoneTextBox";
            this.phoneTextBox.Size = new System.Drawing.Size(100, 20);
            this.phoneTextBox.TabIndex = 13;
            // 
            // nameTextBox
            // 
            this.nameTextBox.Location = new System.Drawing.Point(139, 145);
            this.nameTextBox.Name = "nameTextBox";
            this.nameTextBox.Size = new System.Drawing.Size(203, 20);
            this.nameTextBox.TabIndex = 14;
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(617, 388);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(75, 23);
            this.btnExit.TabIndex = 15;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // btnSubmit
            // 
            this.btnSubmit.Location = new System.Drawing.Point(485, 388);
            this.btnSubmit.Name = "btnSubmit";
            this.btnSubmit.Size = new System.Drawing.Size(75, 23);
            this.btnSubmit.TabIndex = 16;
            this.btnSubmit.Text = "Submit";
            this.btnSubmit.UseVisualStyleBackColor = true;
            this.btnSubmit.Click += new System.EventHandler(this.submitButton_Click);
            // 
            // headWaitronRadioButton
            // 
            this.headWaitronRadioButton.AutoSize = true;
            this.headWaitronRadioButton.Location = new System.Drawing.Point(139, 41);
            this.headWaitronRadioButton.Name = "headWaitronRadioButton";
            this.headWaitronRadioButton.Size = new System.Drawing.Size(85, 17);
            this.headWaitronRadioButton.TabIndex = 17;
            this.headWaitronRadioButton.TabStop = true;
            this.headWaitronRadioButton.Text = "Head Waiter";
            this.headWaitronRadioButton.UseVisualStyleBackColor = true;
            this.headWaitronRadioButton.CheckedChanged += new System.EventHandler(this.headWaitronRadioButton_CheckedChanged);
            // 
            // runnerRadioButton
            // 
            this.runnerRadioButton.AutoSize = true;
            this.runnerRadioButton.Location = new System.Drawing.Point(510, 41);
            this.runnerRadioButton.Name = "runnerRadioButton";
            this.runnerRadioButton.Size = new System.Drawing.Size(60, 17);
            this.runnerRadioButton.TabIndex = 18;
            this.runnerRadioButton.TabStop = true;
            this.runnerRadioButton.Text = "Runner";
            this.runnerRadioButton.UseVisualStyleBackColor = true;
            this.runnerRadioButton.CheckedChanged += new System.EventHandler(this.runnerRadioButton_CheckedChanged);
            // 
            // waitronRadioButton
            // 
            this.waitronRadioButton.AutoSize = true;
            this.waitronRadioButton.Location = new System.Drawing.Point(315, 41);
            this.waitronRadioButton.Name = "waitronRadioButton";
            this.waitronRadioButton.Size = new System.Drawing.Size(56, 17);
            this.waitronRadioButton.TabIndex = 19;
            this.waitronRadioButton.TabStop = true;
            this.waitronRadioButton.Text = "Waiter";
            this.waitronRadioButton.UseVisualStyleBackColor = true;
            this.waitronRadioButton.CheckedChanged += new System.EventHandler(this.waiterRadioButton_CheckedChanged);
            // 
            // EmployeeForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(803, 450);
            this.Controls.Add(this.waitronRadioButton);
            this.Controls.Add(this.runnerRadioButton);
            this.Controls.Add(this.headWaitronRadioButton);
            this.Controls.Add(this.btnSubmit);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.nameTextBox);
            this.Controls.Add(this.phoneTextBox);
            this.Controls.Add(this.paymentTextBox);
            this.Controls.Add(this.hoursTextBox);
            this.Controls.Add(this.tipsTextBox);
            this.Controls.Add(this.empIDTextBox);
            this.Controls.Add(this.nameLabel);
            this.Controls.Add(this.phoneLabel);
            this.Controls.Add(this.paymentLabel);
            this.Controls.Add(this.hoursLabel);
            this.Controls.Add(this.empIDLabel);
            this.Controls.Add(this.tipsLabel);
            this.Controls.Add(this.idTextBox);
            this.Controls.Add(this.idLabel);
            this.Controls.Add(this.btnCancel);
            this.Name = "EmployeeForm";
            this.Text = "EmployeeForm";
            this.Activated += new System.EventHandler(this.EmployeeForm_Activated);
            this.Load += new System.EventHandler(this.EmployeeForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Label idLabel;
        private System.Windows.Forms.TextBox idTextBox;
        private System.Windows.Forms.Label tipsLabel;
        private System.Windows.Forms.Label empIDLabel;
        private System.Windows.Forms.Label hoursLabel;
        private System.Windows.Forms.Label paymentLabel;
        private System.Windows.Forms.Label phoneLabel;
        private System.Windows.Forms.Label nameLabel;
        private System.Windows.Forms.TextBox empIDTextBox;
        private System.Windows.Forms.TextBox tipsTextBox;
        private System.Windows.Forms.TextBox hoursTextBox;
        private System.Windows.Forms.TextBox paymentTextBox;
        private System.Windows.Forms.TextBox phoneTextBox;
        private System.Windows.Forms.TextBox nameTextBox;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnSubmit;
        private System.Windows.Forms.RadioButton headWaitronRadioButton;
        private System.Windows.Forms.RadioButton runnerRadioButton;
        private System.Windows.Forms.RadioButton waitronRadioButton;
    }
}