﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WaiteringSystem.Business;

namespace WaiteringSystem.Presentation
{
    public partial class EmployeeForm : Form
    {
        public bool employeeFormClosed = false;

        public Role.RoleType RoleValue
        {
            get
            {
                return roleValue;
            }
            set
            {
                roleValue = value;
            }
        }

        private Employee employee;
        private EmployeeController employeeController;

        private Role.RoleType roleValue;
        public EmployeeForm(EmployeeController empController)
        {
            InitializeComponent();

            employeeController = empController;
        }

        #region Utility Methods

        private void ShowAll(bool value, Role roleType)
        {
            idLabel.Visible = value;
            idTextBox.Visible = value;

            empIDLabel.Visible = value;
            empIDTextBox.Visible = value;

            nameLabel.Visible = value;
            nameTextBox.Visible = value;

            phoneLabel.Visible = value;
            phoneTextBox.Visible = value;

            paymentLabel.Visible = value;
            paymentTextBox.Visible = value;

            if (!value)
            {
                headWaitronRadioButton.Checked = false;
                waitronRadioButton.Checked = false;
                runnerRadioButton.Checked = false;
            }

            if (value &&
                (roleType.getRoleValue == Role.RoleType.Waiter ||
                 roleType.getRoleValue == Role.RoleType.Runner))
            {
                tipsLabel.Visible = true;
                tipsTextBox.Visible = true;

                hoursLabel.Visible = true;
                hoursTextBox.Visible = true;
            }
            else
            {
                tipsLabel.Visible = false;
                tipsTextBox.Visible = false;

                hoursLabel.Visible = false;
                hoursTextBox.Visible = false;
            }
        }



        private void ClearAll()
        {
            idTextBox.Clear();
            empIDTextBox.Clear();
            nameTextBox.Clear();
            phoneTextBox.Clear();
            paymentTextBox.Clear();
            hoursTextBox.Clear();
            tipsTextBox.Clear();

            headWaitronRadioButton.Checked = false;
            waitronRadioButton.Checked = false;
            runnerRadioButton.Checked = false;
        }

        private void PopulateObject(Role roleType)
        {
            HeadWaiter headW;
            Waiter waiter;
            Runner runner;

            // Create the Employee object using the selected RoleType
            employee = new Employee(roleType.getRoleValue);

            // Populate common Employee fields
            employee.ID = idTextBox.Text;
            employee.EmployeeID = empIDTextBox.Text;
            employee.Name = nameTextBox.Text;
            employee.Telephone = phoneTextBox.Text;

            // Populate role-specific fields
            switch (employee.role.getRoleValue)
            {
                case Role.RoleType.Headwaiter:

                    headW = (HeadWaiter)employee.role;

                    headW.SalaryAmount =
                        decimal.Parse(paymentTextBox.Text);

                    break;

                case Role.RoleType.Waiter:

                    waiter = (Waiter)employee.role;

                    waiter.getRate =
                        decimal.Parse(paymentTextBox.Text);

                    waiter.getShifts =
                        int.Parse(hoursTextBox.Text);

                    waiter.getTips =
                        decimal.Parse(tipsTextBox.Text);

                    break;

                case Role.RoleType.Runner:

                    runner = (Runner)employee.role;

                    runner.getRate =
                        decimal.Parse(paymentTextBox.Text);

                    runner.getShifts =
                        int.Parse(hoursTextBox.Text);

                    break;
            }
        }

        #endregion
        #region Radio Button CheckChanged Events

        private void headWaitronRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            if (headWaitronRadioButton.Checked)
            {
                this.Text = "Add Head Waiter";

                roleValue = Role.RoleType.Headwaiter;

                paymentLabel.Text = "Salary";

                Role selectedRole = new Role();
                selectedRole.getRoleValue = roleValue;

                ShowAll(true, selectedRole);

                idTextBox.Focus();
            }
        }

       

        private void runnerRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            if (runnerRadioButton.Checked)
            {
                this.Text = "Add Runner";

                roleValue = Role.RoleType.Runner;

                paymentLabel.Text = "Day Rate";

                Role selectedRole = new Role();
                selectedRole.getRoleValue = roleValue;

                ShowAll(true, selectedRole);

                idTextBox.Focus();
            }
        }

        #endregion

        #region Button Events

        private void submitButton_Click(object sender, EventArgs e)
        {
            try
            {
                // Make sure a role has been selected
                if (!headWaitronRadioButton.Checked &&
                    !waitronRadioButton.Checked &&
                    !runnerRadioButton.Checked)
                {
                    MessageBox.Show(
                        "Please select an employee role.",
                        "Missing Role",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Warning);

                    return;
                }

                // Validate the common fields
                if (string.IsNullOrWhiteSpace(idTextBox.Text) ||
                    string.IsNullOrWhiteSpace(empIDTextBox.Text) ||
                    string.IsNullOrWhiteSpace(nameTextBox.Text) ||
                    string.IsNullOrWhiteSpace(phoneTextBox.Text) ||
                    string.IsNullOrWhiteSpace(paymentTextBox.Text))
                {
                    MessageBox.Show(
                        "Please complete all required employee details.",
                        "Missing Information",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Warning);

                    return;
                }

                // Validate role-specific fields
                if ((roleValue == Role.RoleType.Waiter ||
                     roleValue == Role.RoleType.Runner) &&
                    string.IsNullOrWhiteSpace(hoursTextBox.Text))
                {
                    MessageBox.Show(
                        "Please enter the number of shifts.",
                        "Missing Information",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Warning);

                    return;
                }

                if (roleValue == Role.RoleType.Waiter &&
                    string.IsNullOrWhiteSpace(tipsTextBox.Text))
                {
                    MessageBox.Show(
                        "Please enter the tips amount.",
                        "Missing Information",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Warning);

                    return;
                }

                // Validate numeric fields
                decimal payment;

                if (!decimal.TryParse(paymentTextBox.Text, out payment))
                {
                    MessageBox.Show(
                        "Payment/Salary must be a valid number.",
                        "Invalid Input",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Warning);

                    paymentTextBox.Focus();
                    return;
                }

                if (roleValue == Role.RoleType.Waiter ||
                    roleValue == Role.RoleType.Runner)
                {
                    int shifts;

                    if (!int.TryParse(hoursTextBox.Text, out shifts))
                    {
                        MessageBox.Show(
                            "Number of shifts must be a valid whole number.",
                            "Invalid Input",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Warning);

                        hoursTextBox.Focus();
                        return;
                    }

                    if (shifts < 0)
                    {
                        MessageBox.Show(
                            "Number of shifts cannot be negative.",
                            "Invalid Input",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Warning);

                        hoursTextBox.Focus();
                        return;
                    }
                }

                if (roleValue == Role.RoleType.Waiter)
                {
                    decimal tips;

                    if (!decimal.TryParse(tipsTextBox.Text, out tips))
                    {
                        MessageBox.Show(
                            "Tips must be a valid number.",
                            "Invalid Input",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Warning);

                        tipsTextBox.Focus();
                        return;
                    }

                    if (tips < 0)
                    {
                        MessageBox.Show(
                            "Tips cannot be negative.",
                            "Invalid Input",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Warning);

                        tipsTextBox.Focus();
                        return;
                    }
                }

                Role selectedRole = new Role();
                selectedRole.getRoleValue = roleValue;

                PopulateObject(selectedRole);

                // Notify the user before submitting
                DialogResult result = MessageBox.Show(
                    "The employee record will now be submitted to the database.",
                    "Submit Employee",
                    MessageBoxButtons.OKCancel,
                    MessageBoxIcon.Information);

                if (result == DialogResult.Cancel)
                {
                    return;
                }

                // Add the employee to the controller/dataset
                employeeController.DataMaintenance(employee);

                // Commit the employee to the database
                bool success = employeeController.FinalizeChanges(employee);

                if (success)
                {
                    MessageBox.Show(
                        "Employee record successfully added to the database.",
                        "Record Added",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Information);

                    // Clear controls for the next employee
                    ClearAll();

                    // Hide the employee controls until another role is selected
                    Role noRole = new Role();
                    ShowAll(false, noRole);
                }
                else
                {
                    MessageBox.Show(
                        "The employee record could not be saved to the database.",
                        "Database Error",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Error);
                }
            }
            catch (FormatException)
            {
                MessageBox.Show(
                    "Please enter valid numeric values for salary, rate, shifts and tips.",
                    "Invalid Input",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "An error occurred while adding the employee:\n\n" +
                    ex.Message,
                    "Error",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }

        private void cancelButton_Click(object sender, EventArgs e)
        {
            ClearAll();

            Role noRole = new Role();
            ShowAll(false, noRole);

            this.Text = "Employee Form";
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            employeeFormClosed = true;
            this.Close();
        }

        #endregion

        #region Form Events

        private void EmployeeForm_Load(object sender, EventArgs e)
        {
            Role noRole = new Role();
            ShowAll(false, noRole);

            ShowAll(false, new Role());
        }

        private void EmployeeForm_Activated(object sender, EventArgs e)
        {
            headWaitronRadioButton.Checked = false;

            Role noRole = new Role();
            ShowAll(false, noRole);
        }

        #endregion

        private void waiterRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            if (waitronRadioButton.Checked)
            {
                this.Text = "Add Waiter";

                roleValue = Role.RoleType.Waiter;

                paymentLabel.Text = "Day Rate";

                Role selectedRole = new Role();
                selectedRole.getRoleValue = roleValue;

                ShowAll(true, selectedRole);

                idTextBox.Focus();
            }
        }
    }
}
